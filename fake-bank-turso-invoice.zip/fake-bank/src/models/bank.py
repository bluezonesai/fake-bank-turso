from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import random
import string

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    pin = db.Column(db.String(4), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    accounts = db.relationship('Account', backref='owner', lazy=True)

    def __repr__(self):
        return f'<User {self.username}>'

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Account(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    account_number = db.Column(db.String(10), unique=True, nullable=False)
    account_type = db.Column(db.String(20), nullable=False)  # 'personal' or 'business'
    balance = db.Column(db.Float, default=1000.0)  # Start with $1000 fake money
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    sent_transactions = db.relationship('Transaction', foreign_keys='Transaction.from_account_id', backref='from_account', lazy=True)
    received_transactions = db.relationship('Transaction', foreign_keys='Transaction.to_account_id', backref='to_account', lazy=True)

    def __init__(self, **kwargs):
        super(Account, self).__init__(**kwargs)
        if not self.account_number:
            self.account_number = self.generate_account_number()

    def generate_account_number(self):
        return ''.join(random.choices(string.digits, k=10))

    def to_dict(self):
        return {
            'id': self.id,
            'account_number': self.account_number,
            'account_type': self.account_type,
            'balance': self.balance,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    from_account_id = db.Column(db.Integer, db.ForeignKey('account.id'), nullable=False)
    to_account_id = db.Column(db.Integer, db.ForeignKey('account.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(200), nullable=True)
    transaction_type = db.Column(db.String(20), nullable=False)  # 'transfer' or 'charge'
    status = db.Column(db.String(20), default='completed')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'from_account_id': self.from_account_id,
            'to_account_id': self.to_account_id,
            'amount': self.amount,
            'description': self.description,
            'transaction_type': self.transaction_type,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

