#!/usr/bin/env bash

# Start the Flask application
exec python src/main.py

